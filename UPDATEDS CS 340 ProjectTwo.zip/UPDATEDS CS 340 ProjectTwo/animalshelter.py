"""
animalshelter.py
Reusable CRUD module for the AAC.animals collection using PyMongo.
"""

from typing import Any, Dict, List, Optional
import os
from pymongo import MongoClient, errors


class AnimalShelter:
    """CRUD operations for the AAC.animals collection in MongoDB."""

    def __init__(
        self,
        user: Optional[str] = None,
        password: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        db: str = "AAC",
        col: str = "animals",
        auth_source: str = "admin",
        connect_timeout_ms: int = 5000,
        server_selection_timeout_ms: int = 5000,
    ) -> None:
        """
        Initialize the MongoDB client/collection.
        Defaults can be overridden by environment variables:
          MONGO_USER, MONGO_PASS, MONGO_HOST, MONGO_PORT, MONGO_DB, MONGO_COL, MONGO_AUTHSOURCE
        """
        self.user = user or os.getenv("MONGO_USER", "aacuser")
        self.password = password or os.getenv("MONGO_PASS", "SNHU2025")
        self.host = host or os.getenv("MONGO_HOST", "nv-desktop-services.apporto.com")
        self.port = int(port or os.getenv("MONGO_PORT", "32366"))
        self.db_name = os.getenv("MONGO_DB", db)
        self.col_name = os.getenv("MONGO_COL", col)
        self.auth_source = os.getenv("MONGO_AUTHSOURCE", auth_source)

        uri = f"mongodb://{self.user}:{self.password}@{self.host}:{self.port}/?authSource={self.auth_source}"

        try:
            self.client = MongoClient(
                uri,
                connectTimeoutMS=connect_timeout_ms,
                serverSelectionTimeoutMS=server_selection_timeout_ms,
            )
            # Fail fast if connection/creds are wrong
            self.client.admin.command("ping")
        except errors.PyMongoError as exc:
            raise RuntimeError(
                f"Unable to connect to MongoDB at {self.host}:{self.port} as {self.user}. "
                f"Check credentials/host/port. Original error: {exc}"
            ) from exc

        self.database = self.client[self.db_name]
        self.collection = self.database[self.col_name]

        # ---------------------------------------------------
        # DATABASE ENHANCEMENT (Milestone 4)
        # Add indexes to improve query performance and scalability
        # ---------------------------------------------------
        try:
            self.collection.create_index("animal_type")
            self.collection.create_index("breed")
            self.collection.create_index("name")
            self.collection.create_index("outcome_type")
            self.collection.create_index("age_upon_outcome_in_weeks")
        except errors.PyMongoError:
            # If index creation fails (permissions, etc.), continue without crashing
            pass

    # -----------------------
    # C = Create
    # -----------------------
    def create(self, data: Dict[str, Any]) -> bool:
        """
        Insert a single document.
        :param data: dictionary of key/value pairs
        :return: True if insert was acknowledged, else False
        """
        if not isinstance(data, dict) or not data:
            return False
        try:
            result = self.collection.insert_one(data)
            return bool(result.acknowledged and result.inserted_id)
        except errors.PyMongoError:
            return False

    # -----------------------
    # R = Read
    # -----------------------
    def read(self, query: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Query for documents using find().
        :param query: dictionary filter for find()
        :return: list of documents (possibly empty)
        """
        if not isinstance(query, dict):
            return []
        try:
            return list(self.collection.find(query))
        except errors.PyMongoError:
            return []

    # -----------------------
    # U = Update
    # -----------------------
    def update(self, query: Dict[str, Any], new_values: Dict[str, Any], many: bool = False) -> int:
        """
        Update document(s) matching the filter.
        :param query: filter to select documents
        :param new_values: dictionary of fields to set
        :param many: if True, update_many; otherwise update_one
        :return: number of modified documents
        """
        if not isinstance(query, dict) or not isinstance(new_values, dict) or not new_values:
            return 0
        try:
            if many:
                result = self.collection.update_many(query, {"$set": new_values})
            else:
                result = self.collection.update_one(query, {"$set": new_values})
            return int(result.modified_count)
        except errors.PyMongoError:
            return 0

    # -----------------------
    # D = Delete
    # -----------------------
    def delete(self, query: Dict[str, Any], many: bool = False) -> int:
        """
        Delete document(s) matching the filter.
        :param query: filter to select documents
        :param many: if True, delete_many; otherwise delete_one
        :return: number of documents deleted
        """
        if not isinstance(query, dict) or not query:
            # Avoid accidental mass deletion with empty filter
            return 0
        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return int(result.deleted_count)
        except errors.PyMongoError:
            return 0